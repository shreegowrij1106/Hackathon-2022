# used to create audio - image pairs

class Pair():

    def __init__(self,name,first,second):
        self.NAME = name
        self.FIRST = first
        self.SECOND = second