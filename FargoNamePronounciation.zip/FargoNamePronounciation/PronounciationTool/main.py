from tkinter import *
from gtts import gTTS
import os
from playsound import playsound

root = Tk()
root.geometry("350x300")
root.configure(bg='ghost white')
root.title("WellsFargo - Name Pronounciation Tool")

Label(root, text = "Pronounciation", font = "arial 20 bold", bg='white smoke').pack()
Label(text ="WellsFargo", font = 'arial 15 bold', bg ='white smoke' , width = '20').pack(side = 'bottom')
Msg = StringVar()
Msg.set("Shree")
lang_dict=gTTS.lang.tts_langs()
print(lang_dict[])
Label(root,text ="Enter your Full Name", font = 'arial 15 bold', bg ='white smoke').place(x=20,y=60)
entry_field = Entry(root, textvariable = Msg ,width ='50')
entry_field.place(x=20,y=100)


def Text_to_speech():
    Message = entry_field.get()
    print("Name ==>",Message)
    language = 'en'
    speech = gTTS(text = Message,lang = language, slow = False)
    fileName=str(Message).replace(' ','')+'.mp3'
    print("Filename ",fileName)
    speech.save(fileName)
    os.system("start "+fileName)

def Exit():
    root.destroy()

def Reset():
    Msg.set("")

Button(root, text = "PLAY", font = 'arial 15 bold' , command = Text_to_speech ,width = '4').place(x=25,y=140)
Button(root, font = 'arial 15 bold',text = 'EXIT', width = '4' , command = Exit, bg = 'OrangeRed1').place(x=100 , y = 140)
Button(root, font = 'arial 15 bold',text = 'RESET', width = '6' , command = Reset).place(x=175 , y = 140)

if __name__ == "__main__":
    root.mainloop()
